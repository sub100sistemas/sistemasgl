exports.ids = [0];
exports.modules = {

/***/ 146:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(175);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("3d09c22f", content, true, context)
};

/***/ }),

/***/ 174:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_d20c41d4_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(146);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_d20c41d4_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_d20c41d4_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_d20c41d4_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_d20c41d4_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 175:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".footer-logo img[data-v-d20c41d4]{width:160px}.footer-widget .comercial[data-v-d20c41d4],.footer-widget-content .endereco[data-v-d20c41d4]{font-size:16px;line-height:1.4;margin-bottom:20px}.footer-social-inline a img[data-v-d20c41d4]{color:#5d5fef;height:34px}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 231:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/Footer.vue?vue&type=template&id=d20c41d4&scoped=true
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"footer-section"},[_vm._ssrNode("<div class=\"container\" data-v-d20c41d4>","</div>",[_vm._ssrNode("<div class=\"row\" data-v-d20c41d4>","</div>",[_vm._ssrNode("<div class=\"col-xl-3 col-md-6 max-mb-50\" data-v-d20c41d4>","</div>",[_vm._ssrNode("<div"+_vm._ssrClass("footer-widget footer-logo",_vm.addClassName)+" data-v-d20c41d4>","</div>",[_vm._ssrNode("<a href=\"https://sistemasgl.com.br\" aria-label=\"SUB100 Loteamentos\" class=\"pb-3\" data-v-d20c41d4>","</a>",[_c('inline-svg',{staticClass:"light-logo",attrs:{"src":"/images/logo/dark-logo.svg?20220404","alt":"SUB100 Loteamentos"}})],1),_vm._ssrNode(" <h6 class=\"footer-widget-title mb-0\" data-v-d20c41d4>Localização</h6> <div class=\"footer-widget-content\" data-v-d20c41d4><div class=\"content\" data-v-d20c41d4><p class=\"endereco\" data-v-d20c41d4>Rua Machado de Assis, 621<br data-v-d20c41d4>\n                            Zona 06 - CEP 87015-580<br data-v-d20c41d4>\n                            Maringá - PR</p></div></div>")],2),_vm._ssrNode(" <a data-fancybox=\"map\" href=\"https://www.google.com/maps/search/?api=1&query=rua+machado+de+assis+621+maringa+pr\" class=\"col-xs-12 btn btn-outline-secondary btn-hover-secondary-two mt-4 mt-md-0 mx-w-100\" data-v-d20c41d4>Como chegar</a>")],2),_vm._ssrNode(" <div class=\"col-xl-6 col-md-6 col-sm-7 max-mb-50\" data-v-d20c41d4><div"+_vm._ssrClass("footer-widget text-left text-xl-center",_vm.addClassName)+" data-v-d20c41d4><h6 class=\"footer-widget-title\" data-v-d20c41d4>Siga nas redes sociais</h6> <div class=\"footer-social-inline d-block\" data-v-d20c41d4><a href=\"https://www.facebook.com/sub100brasil\" target=\"_blank\" data-v-d20c41d4><img src=\"/images/icons/facebook.svg?20220407\" width=\"30\" height=\"34\" alt=\"Facebook\" data-v-d20c41d4></a> <a href=\"https://www.instagram.com/sub100brasil/\" target=\"_blank\" data-v-d20c41d4><img src=\"/images/icons/instagram.svg?20220407\" width=\"30\" height=\"34\" alt=\"Instagram\" data-v-d20c41d4></a> <a href=\"https://www.linkedin.com/company/sub100/\" target=\"_blank\" data-v-d20c41d4><img src=\"/images/icons/linkedin.svg?2020407\" width=\"34\" height=\"34\" alt=\"Linkedin\" data-v-d20c41d4></a> <a href=\"https://blog.sub100sistemas.com.br/\" target=\"_blank\" data-v-d20c41d4><img src=\"/images/icons/blog.svg?2022047\" width=\"34\" height=\"34\" alt=\"Blog\" data-v-d20c41d4></a></div></div> <div class=\"max-mt-70 text-md-left text-xl-center pr-4 fz-14\" data-v-d20c41d4>\n                    Há 24 anos, a SUB100 Sistemas ajuda a realizar os sonhos de milhões de pessoas, conectando através do seu Sistema de Gestão de Loteamentos - SGL a corretores, imobiliárias, loteadoras, incorporadoras e construtoras às pessoas que procuram um novo lugar para morar ou investir. \n                </div></div> "),_vm._ssrNode("<div class=\"col-xl-3 col-md-5 max-mb-50 text-left text-xl-right\" data-v-d20c41d4>","</div>",[_vm._ssrNode("<h6 class=\"footer-widget-title mb-0\" data-v-d20c41d4>Comercial</h6> "),_vm._ssrNode("<div"+_vm._ssrClass("footer-widget",_vm.addClassName)+" data-v-d20c41d4>","</div>",[_vm._ssrNode("<div class=\"content\" data-v-d20c41d4><p class=\"comercial\" data-v-d20c41d4><a href=\"tel://04430325200\" aria-label=\"ligar\" title=\"Clique aqui para ligar agora\" target=\"_blank\" data-v-d20c41d4>44 3032-5200</a><br data-v-d20c41d4> <a href=\"mailto:contato@sub100.com.br\" aria-label=\"email\" title=\"Clique aqui para enviar email\" target=\"_blank\" data-v-d20c41d4>contato@sub100.com.br</a></p></div> <a href=\"https://web.whatsapp.com/send?phone=554430325208&text=Quero%20mais%20informa%C3%A7%C3%B5es%20sobre%20do%20Sistema%C2%A0SGL\" aria-label=\"whatsApp\" title=\"Quero contato via WhatsApp\" target=\"_blank\" class=\"btn btn-primary mx-w-100 mb-3 d-none d-xl-block pl-0 pr-0\" data-v-d20c41d4>Quero contato via WhatsApp</a> <a href=\"https://api.whatsapp.com/send?phone=554430325208&text=Quero%20mais%20informa%C3%A7%C3%B5es%20sobre%20do%20Sistema%C2%A0SGL\" aria-label=\"whatsApp\" title=\"Quero contato via WhatsApp\" target=\"_blank\" class=\"btn btn-primary mx-w-100 mb-3 d-block d-xl-none pl-0 pr-0\" data-v-d20c41d4>Quero contato via WhatsApp</a> "),_vm._ssrNode("<div class=\"footer-widget-content\" data-v-d20c41d4>","</div>",[_vm._ssrNode("<ul data-v-d20c41d4>","</ul>",[_vm._ssrNode("<li data-v-d20c41d4>","</li>",[_c('n-link',{attrs:{"to":"/conteudo/termos-de-uso/","aria-label":"Termos de uso"}},[_vm._v("Termos de uso")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-d20c41d4>","</li>",[_c('n-link',{attrs:{"to":"/conteudo/politica-de-privacidade/","aria-label":"Política de privacidade"}},[_vm._v("Política de privacidade")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-d20c41d4>","</li>",[_c('ColorMode')],1)],2)])],2)],2)],2),_vm._ssrNode(" <div class=\"row max-mt-20\" data-v-d20c41d4><div class=\"col\" data-v-d20c41d4><p class=\"copyright text-left text-xl-center\" data-v-d20c41d4><span class=\"d-block d-md-inline\" data-v-d20c41d4>"+_vm._ssrEscape("© "+_vm._s(new Date().getFullYear())+" ")+"<b data-v-d20c41d4>SUB100</b> Loteamentos</span> <img src=\"/images/icons/heart.svg?20220407\" width=\"14\" height=\"14\" alt=\"Heart\" data-v-d20c41d4> by <a href=\"https://sub100sistemas.com.br/\" aria-label=\"SUB100 Sistemas\" target=\"_blank\" data-v-d20c41d4><b data-v-d20c41d4>SUB100</b> Sistemas</a></p></div></div>")],2),_vm._ssrNode(" "),_c('client-only',[_c('back-to-top',{staticClass:"scroll-top",attrs:{"bottom":"30px"}},[_c('i',{staticClass:"arrow-top fal fa-long-arrow-up"}),_vm._v(" "),_c('i',{staticClass:"arrow-bottom fal fa-long-arrow-up"})])],1)],2);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/Footer.vue?vue&type=template&id=d20c41d4&scoped=true

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/Footer.vue?vue&type=script&lang=js
/* harmony default export */ var Footervue_type_script_lang_js = ({props:['addClassName','addBackgroundColor'],components:{ColorMode:()=>__webpack_require__.e(/* import() */ 10).then(__webpack_require__.bind(null, 260))}});
// CONCATENATED MODULE: ./components/sub100/Footer.vue?vue&type=script&lang=js
 /* harmony default export */ var sub100_Footervue_type_script_lang_js = (Footervue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/Footer.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(174)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  sub100_Footervue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "d20c41d4",
  "4f79ede5"
  
)

/* harmony default export */ var Footer = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-footer.js.map
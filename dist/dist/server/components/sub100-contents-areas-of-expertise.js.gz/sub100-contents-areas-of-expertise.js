exports.ids = [52];
exports.modules = {

/***/ 164:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(211);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("712852f4", content, true, context)
};

/***/ }),

/***/ 210:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AreasOfExpertise_vue_vue_type_style_index_0_id_2cab56c5_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(164);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AreasOfExpertise_vue_vue_type_style_index_0_id_2cab56c5_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AreasOfExpertise_vue_vue_type_style_index_0_id_2cab56c5_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AreasOfExpertise_vue_vue_type_style_index_0_id_2cab56c5_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AreasOfExpertise_vue_vue_type_style_index_0_id_2cab56c5_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 211:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".icon .fil0[data-v-2cab56c5]{fill:#00d39b!important;fill-rule:nonzero}.dark-mode .icon-box[data-v-2cab56c5]{background-color:#161821!important}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 267:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/AreasOfExpertise.vue?vue&type=template&id=2cab56c5&scoped=true
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"section pt-2 pb-5"},[_vm._ssrNode("<div class=\"container\" data-v-2cab56c5>","</div>",[_vm._ssrNode("<div class=\"section-title text-center\" data-v-2cab56c5><span class=\"sub-title\" data-v-2cab56c5>Áreas de Atuação</span> <h2 class=\"title\" data-v-2cab56c5>A SUB100 Sistemas atua em <span data-v-2cab56c5>3 principais</span> áreas</h2></div> "),_vm._ssrNode("<div class=\"row row-cols-xl-3 row-cols-sm-2 row-cols-1 no-gutters\" data-v-2cab56c5>","</div>",_vm._l(_vm.items,function(item){return _vm._ssrNode("<div class=\"col\" data-v-2cab56c5>","</div>",[_vm._ssrNode("<div data-vivus-hover class=\"icon-box text-center\" data-v-2cab56c5>","</div>",[_vm._ssrNode("<div class=\"icon\" data-v-2cab56c5>","</div>",[_c('inline-svg',{attrs:{"src":item.icon,"alt":item.alt}})],1),_vm._ssrNode(" <div class=\"content\" data-v-2cab56c5><h4 class=\"title\" data-v-2cab56c5>"+_vm._ssrEscape(_vm._s(item.title))+"</h4> <div class=\"desc\" data-v-2cab56c5><p data-v-2cab56c5>"+_vm._ssrEscape(_vm._s(item.desc))+"</p></div></div>")],2)]);}),0)],2)]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/AreasOfExpertise.vue?vue&type=template&id=2cab56c5&scoped=true

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/AreasOfExpertise.vue?vue&type=script&lang=js
/* harmony default export */ var AreasOfExpertisevue_type_script_lang_js = ({data(){return{items:[{id:1,icon:"/images/icons/administrativo.svg?20220404",alt:"icon",title:"Sistemas",desc:"Sistemas inteligentes para gestão de vendas e administração de loteamentos que permitem otimizar e agilizar os processos administrativos e financeiros da sua empresa."},{id:2,icon:"/images/icons/portal.svg?20220404",alt:"icon",title:"Portal de imóveis",desc:"O maior portal do Paraná, com mais de 50 mil imóveis anunciados e todos com informações completas tais como fotos, mapas e vídeos, distribuídos em mais de 445 cidades e 22 estados."},{id:3,icon:"/images/icons/sites.svg?20220404",alt:"icon",title:"Sites",desc:"Desenvolvimento de sites para o mercado imobiliário, loteadoras e setor da construção civil."}]};}});
// CONCATENATED MODULE: ./components/sub100/contents/AreasOfExpertise.vue?vue&type=script&lang=js
 /* harmony default export */ var contents_AreasOfExpertisevue_type_script_lang_js = (AreasOfExpertisevue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/AreasOfExpertise.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(210)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  contents_AreasOfExpertisevue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "2cab56c5",
  "5009ff08"
  
)

/* harmony default export */ var AreasOfExpertise = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-areas-of-expertise.js.map
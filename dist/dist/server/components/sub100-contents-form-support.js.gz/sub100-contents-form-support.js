exports.ids = [55];
exports.modules = {

/***/ 270:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/FormSupport.vue?vue&type=template&id=6995eadb
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"contact-us-page-wrapper section-padding-top-60"},[_vm._ssrNode("<div class=\"contact-form-section pt-5 text-center\">","</div>",[_vm._ssrNode("<div class=\"container\">","</div>",[_vm._ssrNode("<div class=\"row\">","</div>",[_vm._ssrNode("<div class=\"offset-lg-2 col-lg-8\">","</div>",[_vm._ssrNode("<div class=\"contact-title\"><h2 class=\"sub-title\">Envie uma mensagem utilizando o formulário abaixo:</h2></div> "),_c('ContactForm')],2)])])])]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/FormSupport.vue?vue&type=template&id=6995eadb

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/FormSupport.vue?vue&type=script&lang=js
/* harmony default export */ var FormSupportvue_type_script_lang_js = ({components:{ContactForm:()=>__webpack_require__.e(/* import() */ 7).then(__webpack_require__.bind(null, 274))}});
// CONCATENATED MODULE: ./components/sub100/contents/FormSupport.vue?vue&type=script&lang=js
 /* harmony default export */ var contents_FormSupportvue_type_script_lang_js = (FormSupportvue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/FormSupport.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  contents_FormSupportvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "40d0239a"
  
)

/* harmony default export */ var FormSupport = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-form-support.js.map
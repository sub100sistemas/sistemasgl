exports.ids = [24];
exports.modules = {

/***/ 158:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(199);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("20649011", content, true, context)
};

/***/ }),

/***/ 198:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroCliente_vue_vue_type_style_index_0_id_2b593777_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(158);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroCliente_vue_vue_type_style_index_0_id_2b593777_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroCliente_vue_vue_type_style_index_0_id_2b593777_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroCliente_vue_vue_type_style_index_0_id_2b593777_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroCliente_vue_vue_type_style_index_0_id_2b593777_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 199:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".sub100-shape[data-v-2b593777]{bottom:-1px;left:0;overflow:hidden;position:absolute;width:100%;z-index:1}#curvaBackgroundBottom .fil0[data-v-2b593777]{fill:#03d29c}#curvaBackgroundBottom .fil1[data-v-2b593777]{fill:#f7f8ff}.section-bottom-shape-three.sub100-shape[data-v-2b593777]{transform:none}.mapaSub100[data-v-2b593777]{margin-bottom:20px;margin-top:-20px;max-height:490px;position:inherit;z-index:9}.dark-mode #curvaBackgroundBottom .fil1[data-v-2b593777]{fill:#111}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 282:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroCliente.vue?vue&type=template&id=2b593777&scoped=true
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"position-relative pt-0 mt-5 mt-md-0 pb-5"},[_vm._ssrNode("<div class=\"container\" data-v-2b593777><div class=\"row row-cols-lg-2 row-cols-1 align-items-center pt-2 pt-xl-0\" data-v-2b593777><div class=\"col\" data-v-2b593777><div class=\"faq-content-area\" data-v-2b593777><div data-aos=\"fade-up\" class=\"section-title text-left mb-50\" data-v-2b593777><span class=\"sub-title mb\" data-v-2b593777><strong data-v-2b593777>Clientes</strong></span> <h4 class=\"title fz-30 max-mb-30\" data-v-2b593777>Onde nossos <span data-v-2b593777>clientes estão</span></h4> <p class=\"max-mb-30\" data-v-2b593777>Nossos clientes estão distribuídos em todas as regiões do Brasil e diante desta realidade, aprimoramos nosso Sistema de Gestão de Loteamento o SGL, adequando-o à várias situações, desde a sua usabilidade até o desempenho do programa frente a baixa qualidade de sinal da internet em determinadas regiões.</p> <h4 class=\"title fz-30 max-mb-30\" data-v-2b593777>Com o que <span data-v-2b593777>eles atuam</span></h4> <p class=\"max-mb-30\" data-v-2b593777>Atendemos clientes que fazem toda a incorporação do empreendimento, clientes que utilizam o Sistema de Gestão de Loteamento SGL para vender seus próprios empreendimentos ou de parceiros e clientes que apenas administram os recebíveis.</p></div></div></div> <div class=\"col\" data-v-2b593777><div class=\"faq-right-image mapaSub100 d-table mt-3 mt-xl-0 mb-0 mb-xl-3\" data-v-2b593777><img src=\"/images/sub100/mapa.svg?20230705\" width=\"515\" height=\"520\" alt=\"Nossos clientes\" data-v-2b593777></div></div></div></div> "),_vm._ssrNode("<div class=\"sub100-shape d-none d-md-block\" data-v-2b593777>","</div>",[_vm._ssrNode("<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" width=\"2498px\" height=\"216px\" version=\"1.1\" viewBox=\"0 0 2498 215.97\" style=\"shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd\" data-v-2b593777>","</svg>",[_c('metadata',{attrs:{"id":"CorelCorpID_0Corel-Layer"}}),_vm._ssrNode(" <g id=\"curvaBackgroundBottom\" data-v-2b593777><path d=\"M2498 27.23c-169.56,-35.82 -526.9,-66.28 -1057.41,114.83 -353.07,120.56 -794.58,34.94 -794.58,34.94 0,0 -348.98,-73.15 -495.36,-38.79 -60.57,14.22 -110.63,37.34 -150.65,62.1l0 14.93 2498 0 0 -188.01 0 0z\" class=\"fil0\" data-v-2b593777></path> <path d=\"M2498 56.71c-174.44,-37.7 -527.25,-68.32 -1048.16,99.83 -355.92,114.9 -796.94,21.15 -796.94,21.15 0,0 -348.49,-79.6 -495.79,-47.66 -63.51,13.78 -115.75,36.63 -157.11,61.97l0 23.97 2498 0 0 -159.26 0 0z\" class=\"fil1\" data-v-2b593777></path></g>")],2)])],2);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/HeroCliente.vue?vue&type=template&id=2b593777&scoped=true

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/HeroCliente.vue

var script = {}
function injectStyles (context) {
  
  var style0 = __webpack_require__(198)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "2b593777",
  "60420746"
  
)

/* harmony default export */ var HeroCliente = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-hero-cliente.js.map
exports.ids = [28];
exports.modules = {

/***/ 156:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(195);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("57be6011", content, true, context)
};

/***/ }),

/***/ 157:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(197);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("6ea3e1dd", content, true, context)
};

/***/ }),

/***/ 194:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_0_id_42fa3489_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(156);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_0_id_42fa3489_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_0_id_42fa3489_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_0_id_42fa3489_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_0_id_42fa3489_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 195:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, "a:focus .desc,a:hover .desc,a:visited .desc{color:dimgray!important}.section-top-shape{left:0;position:absolute;top:0;width:100%;z-index:1}.section-top-shape svg path{fill:#fff}.section-top-shape svg{height:50px;width:100%}@media only screen and (max-width:767px){.section-top-shape svg{height:29px!important}}.section-title span{font-weight:700!important}@media only screen and (max-width:767px){.section-title.module{background:#e9eefd}}.dark-mode .section-top-shape svg path{fill:#161821}.dark-mode .icon-box{background-color:#111!important}.dark-mode .section-title.module{background:#161821!important}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 196:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_1_id_42fa3489_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(157);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_1_id_42fa3489_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_1_id_42fa3489_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_1_id_42fa3489_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroModule_vue_vue_type_style_index_1_id_42fa3489_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 197:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".no-gutters polygon[data-v-42fa3489]{stroke:blue}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 257:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroModule.vue?vue&type=template&id=42fa3489&scoped=true
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"section-padding pb-5 position-relative bg-f8f8f8",class:_vm.addClassName},[_vm._ssrNode("<div class=\"section-top-shape\" data-v-42fa3489><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\" preserveAspectRatio=\"none\" height=\"100\" data-v-42fa3489><path d=\"M 0 0 L100 0 Q 50 200 0 0\" data-v-42fa3489></path></svg></div> "),_vm._ssrNode("<div class=\"container\" data-v-42fa3489>","</div>",[_vm._ssrNode("<div class=\"section-title module text-center mb-3 mb-md-5 p-3 p-xl-0\" data-v-42fa3489>"+(_vm.mostrarTitulo?"<span class=\"sub-title\" data-v-42fa3489>Módulos</span>":"<h1 class=\"sub-title\" data-v-42fa3489>Loteamentos</h1>")+" <h2 class=\"title\" data-v-42fa3489>Conheça os principais módulos do <span data-v-42fa3489>Sistema de Gestão de loteamentos SGL</span></h2></div> "),_vm._ssrNode("<div class=\"row row-cols-xl-3 row-cols-sm-2 row-cols-1 no-gutters\" data-v-42fa3489>","</div>",_vm._l(_vm.items,function(item){return _vm._ssrNode("<div class=\"col\" data-v-42fa3489>","</div>",[_vm._ssrNode("<a"+_vm._ssrAttr("href",item.link)+" class=\"icon-box text-center\" data-v-42fa3489>","</a>",[_vm._ssrNode("<div class=\"icon\" data-v-42fa3489>","</div>",[_c('inline-svg',{attrs:{"src":item.icone,"alt":item.alt}})],1),_vm._ssrNode(" <div class=\"content\" data-v-42fa3489><h3 class=\"title\" data-v-42fa3489>"+_vm._ssrEscape(_vm._s(item.title))+"</h3> <div class=\"desc\" data-v-42fa3489><p data-v-42fa3489>"+_vm._ssrEscape(_vm._s(item.desc))+"</p></div> <span class=\"link\" data-v-42fa3489>Saiba mais <i class=\"far fa-long-arrow-right\" data-v-42fa3489></i></span></div>")],2)]);}),0)],2)],2);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/HeroModule.vue?vue&type=template&id=42fa3489&scoped=true

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroModule.vue?vue&type=script&lang=js
/* harmony default export */ var HeroModulevue_type_script_lang_js = ({props:['addClassName','mostrarTitulo'],data(){return{items:[{id:1,icone:"/images/icons/atendimento.svg",alt:"Controle de atendimentos",title:"Controle de atendimentos",desc:"Gestão de interessados com importação e distribuição de leads automatizados. Etapa do funil de vendas personalizada e histórico de atendimento. Represamento de vendas de forma simples e intuitiva. Integração com Facebook e outros.",link:"/modulos/controle-de-atendimentos/"},{id:2,icone:"/images/icons/simulador.svg?20220404",alt:"Simulador de vendas",title:"Simulador de vendas",desc:"Poderoso espelho de vendas com um workflow personalizado para reservas, propostas e vendas. Oferecemos controle de alçadas e uma gestão completa de honorários. Além disso, nossa plataforma possui integração nativa com assinatura eletrônica, garantindo segurança e validade jurídica aos documentos assinados.",link:"/modulos/simulador-de-vendas/"},{id:3,icone:"/images/icons/mapaInterativo.svg?20220404",alt:"Loteamentos",title:"Mapa interativo",desc:"Desenvolva seu espelho de venda através do mapa interativo. Controle a quantidade de reservas por parceiros e corretores. Elimine duplicidades de reservas e propostas em cada unidade.",link:"/modulos/mapa-interativo/"},{id:4,icone:"/images/icons/administrativo.svg?20220404",alt:"Administrativo",title:"Administrativo",desc:"Gerencie de forma RÁPIDA, SIMPLES e EFICAZ as atividades cotidianas de cada unidade, tais como: aditivo, cessão de direito, rescisão, quitação de contrato, remessa, retorno, conciliação bancária e cálculos automáticos de antecipação.",link:"/modulos/administrativo/"},{id:5,icone:"/images/icons/financeiro.svg?20220404",alt:"Financeiro",title:"Financeiro",desc:"Total controle da Gestão Financeira. Contas a pagar e receber, reajuste de cobrança, emissão de alerta de vencimento e integração bancária.",link:"/modulos/financeiro/"},{id:6,icone:"/images/icons/agenda.svg?20220404",alt:"Gestão de inadimplência",title:"Gestão de inadimplência",desc:"Controle toda a situação financeira e diminua o risco de inadimplência de sua carteira de recebíveis através das etapas de cobrança que o sistema de gestão de loteamento SGL disponibiliza. Utilize a régua de cobrança para estreitar a relação com seus clientes por meio de comunicados e alertas de pré e pós vencimentos.",link:"/modulos/gestao-de-inadimplencia/"},{id:7,icone:"/images/icons/fiscal.svg?20220404",alt:"Fiscal",title:"Fiscal",desc:"Preparado para exportação de arquivos SPED e DIMOB para o fisco, além de fornecer aos clientes extratos para declaração do Imposto de Renda.",link:"/modulos/fiscal/"},{id:8,icone:"/images/icons/integracao.svg?20220404",alt:"Integrador",title:"Integrador",desc:"O programa SGL permite integrações que vão desde à captação de leads, comunicadores, consultas de crédito até sistemas contábeis e fiscais.",link:"/modulos/integrador/"},{id:9,icone:"/images/icons/usuario.svg?20220404",alt:"Portal do cliente",title:"Portal do cliente",desc:"Solicitação de 2ª via de boletos, extratos para declaração do imposto de renda, atualização cadastral  e acompanhamento de obras entre outras funcionalidades.",link:"/modulos/portal-de-cliente/"}]};}});
// CONCATENATED MODULE: ./components/sub100/HeroModule.vue?vue&type=script&lang=js
 /* harmony default export */ var sub100_HeroModulevue_type_script_lang_js = (HeroModulevue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/HeroModule.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(194)
if (style0.__inject__) style0.__inject__(context)
var style1 = __webpack_require__(196)
if (style1.__inject__) style1.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  sub100_HeroModulevue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "42fa3489",
  "b394be60"
  
)

/* harmony default export */ var HeroModule = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-hero-module.js.map
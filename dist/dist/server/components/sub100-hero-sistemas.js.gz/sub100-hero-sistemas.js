exports.ids = [29];
exports.modules = {

/***/ 154:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(191);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("3f6a028e", content, true, context)
};

/***/ }),

/***/ 190:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroSistemas_vue_vue_type_style_index_0_id_32058f06_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(154);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroSistemas_vue_vue_type_style_index_0_id_32058f06_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroSistemas_vue_vue_type_style_index_0_id_32058f06_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroSistemas_vue_vue_type_style_index_0_id_32058f06_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroSistemas_vue_vue_type_style_index_0_id_32058f06_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 191:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".homeSistema[data-v-32058f06]{height:auto;width:100%}@media only screen and (max-width:767px){.intro5-content[data-v-32058f06]{padding:40px 15px}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 255:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroSistemas.vue?vue&type=template&id=32058f06&scoped=true
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"intro5-section section"},[_vm._ssrNode("<div class=\"container\" data-v-32058f06>","</div>",[_vm._ssrNode("<div class=\"row row-cols-lg-2 row-cols-1 flex-column-reverse flex-lg-row max-mb-n30\" data-v-32058f06>","</div>",[_vm._ssrNode("<div class=\"col align-self-center max-mb-30\" data-v-32058f06>","</div>",[_vm._ssrNode("<div class=\"intro5-content pt-0 pt-md-4\" data-v-32058f06>","</div>",[_vm._ssrNode("<h1 class=\"title fz-26 text-white max-mb-30\" data-v-32058f06>O <span data-v-32058f06>Sistema de Gestão de Loteamentos SGL</span> possui soluções inovadoras para quem incorpora e administra loteamentos além de outros empreendimentos.</h1> <div class=\"desc\" data-v-32058f06><p class=\"text-white\" data-v-32058f06>Um programa desenvolvido para atender todas as áreas de administração do loteamento, que se iniciam no primeiro atendimento e vão até o último recebível.</p> <p class=\"text-white\" data-v-32058f06>O Sistema de Gestão de Loteamento SGL oferece módulos de controle de atendimento, simulador de vendas, controle e administração financeira e fiscal do empreendimento.</p></div> "),_c('n-link',{staticClass:"btn btn-primary mr-0 mr-md-3 mb-0 mb-md-3 mx-w-100",attrs:{"to":"/quero-uma-demonstracao/","aria-label":"Quero uma demonstração"}},[_vm._v("\n                        Quero uma demonstração\n                    ")]),_vm._ssrNode(" <a data-fancybox=\"videoSgl4\" href=\"https://youtu.be/-VNMWEzQLlo\" aria-label=\"Assista o vídeo do SGL\" data-width=\"100%\" data-height=\"100%\" class=\"btn btn-outline-primary btn-hover-primary-two text-white mb-0 mb-md-3 mx-w-100\" data-v-32058f06>\n                        Assista o vídeo do SGL\n                    </a>")],2)]),_vm._ssrNode(" <div class=\"col scene pt-5 pt-xl-0\" data-v-32058f06><div data-depth=\"0.1\" class=\"intro5-image\" data-v-32058f06><img src=\"/images/sub100/home.svg?20220407\" width=\"540\" height=\"485\" alt=\"Sistema de Gestão de Loteamentos SGL\" class=\"homeSistema\" data-v-32058f06></div></div>")],2)])]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/HeroSistemas.vue?vue&type=template&id=32058f06&scoped=true

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroSistemas.vue?vue&type=script&lang=js
/* harmony default export */ var HeroSistemasvue_type_script_lang_js = ({props:['addClassName','imgSrc','dataDepth']});
// CONCATENATED MODULE: ./components/sub100/HeroSistemas.vue?vue&type=script&lang=js
 /* harmony default export */ var sub100_HeroSistemasvue_type_script_lang_js = (HeroSistemasvue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/HeroSistemas.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(190)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  sub100_HeroSistemasvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "32058f06",
  "fa23d116"
  
)

/* harmony default export */ var HeroSistemas = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-hero-sistemas.js.map
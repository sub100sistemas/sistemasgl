exports.ids = [49];
exports.modules = {

/***/ 264:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/AboutUs.vue?vue&type=template&id=225d3486
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"about-section pt-5 pb-3",class:_vm.addClassName},[_vm._ssrNode("<div class=\"container\"><div class=\"row align-items-center\"><div class=\"col order-2\"><div class=\"about-content max-w-100 text-center\"><h1 class=\"sub-title\">SUB100<strong>Sistemas</strong></h1> <h3 class=\"title\">23 anos <span> de experiência</span></h3> <p class=\"fz-18\">\n                        Nesse período adquirimos conhecimento sobre o setor de loteamentos e incorporações, o que nos proporcionou desenvolver sistemas que realmente ajudam nossos clientes a serem mais eficientes e competitivos diante de seus concorrentes.<br>A SUB100 Sistemas foi fundada em 2000, na cidade de Maringá estado do Paraná.\n                    </p></div></div></div></div>")]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/AboutUs.vue?vue&type=template&id=225d3486

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/AboutUs.vue?vue&type=script&lang=js
/* harmony default export */ var AboutUsvue_type_script_lang_js = ({props:['addClassName'],components:{ShapeWithAnimation:()=>__webpack_require__.e(/* import() */ 5).then(__webpack_require__.bind(null, 141))}});
// CONCATENATED MODULE: ./components/sub100/contents/AboutUs.vue?vue&type=script&lang=js
 /* harmony default export */ var contents_AboutUsvue_type_script_lang_js = (AboutUsvue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/AboutUs.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  contents_AboutUsvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "25b60ed3"
  
)

/* harmony default export */ var AboutUs = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-about-us.js.map
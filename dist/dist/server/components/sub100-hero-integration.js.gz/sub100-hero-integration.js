exports.ids = [26];
exports.modules = {

/***/ 159:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(201);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("6c55a07f", content, true, context)
};

/***/ }),

/***/ 200:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroIntegration_vue_vue_type_style_index_0_id_741b15d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(159);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroIntegration_vue_vue_type_style_index_0_id_741b15d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroIntegration_vue_vue_type_style_index_0_id_741b15d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroIntegration_vue_vue_type_style_index_0_id_741b15d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroIntegration_vue_vue_type_style_index_0_id_741b15d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 201:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".top-shape-integration svg[data-v-741b15d0]{top:-20PX}.bottom-shape-integration svg[data-v-741b15d0],.top-shape-integration svg[data-v-741b15d0]{height:auto;left:0;overflow:hidden;position:absolute;vertical-align:middle;width:100%;z-index:0}.bottom-shape-integration svg[data-v-741b15d0]{bottom:-50px}@media only screen and (max-width:767px){.bottom-shape-integration svg[data-v-741b15d0]{bottom:-45px}}.tomada[data-v-741b15d0]{height:160px;left:300px;top:291px;width:415px;z-index:-1}.empresa[data-v-741b15d0],.tomada[data-v-741b15d0]{position:absolute}.empresa[data-v-741b15d0]{height:135px;left:140px;top:166px;width:460px;z-index:1}#integracaoVetor .fil0[data-v-741b15d0]{fill:#f8f8f8}#integracaoVetor .fil2[data-v-741b15d0]{fill:#03d29c;fill-rule:nonzero}#integracaoVetor .fil1[data-v-741b15d0]{fill:#e9eefd;fill-rule:nonzero}#integracaoVetorBottom .fil0[data-v-741b15d0]{fill:#fefefe}#integracaoVetorBottom .fil1[data-v-741b15d0]{fill:#e9eefd;fill-rule:nonzero}.backgroundIntegration[data-v-741b15d0]{background:#e9eefd}.dark-mode #integracaoVetor .fil0[data-v-741b15d0]{fill:#111}.dark-mode #integracaoVetor .fil2[data-v-741b15d0]{fill:#03d29c;fill-rule:nonzero}.dark-mode #integracaoVetor .fil1[data-v-741b15d0]{fill:#111;fill-rule:nonzero}.dark-mode #integracaoVetorBottom .fil0[data-v-741b15d0]{fill:#161821}.dark-mode #integracaoVetorBottom .fil1[data-v-741b15d0]{fill:#111;fill-rule:nonzero}.dark-mode .backgroundIntegration[data-v-741b15d0]{background:#111}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 283:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroIntegration.vue?vue&type=template&id=741b15d0&scoped=true
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"section-padding position-relative pt-0 pb-0 pb-md-5 backgroundIntegration"},[_vm._ssrNode("<div class=\"top-shape-integration\" data-v-741b15d0><svg xmlns=\"http://www.w3.org/2000/svg\" aria-label=\"Empresa\" xml:space=\"preserve\" width=\"1920\" height=\"225\" version=\"1.1\" viewBox=\"0 0 67733.32 7894.46\" style=\"shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd\" data-v-741b15d0><g id=\"integracaoVetor\" data-v-741b15d0><rect x=\"-0\" width=\"67733.32\" height=\"7690.22\" class=\"fil0\" data-v-741b15d0></rect> <path d=\"M-0 7135.76c180.82,-159.81 373.85,-316.38 576.45,-470.37 473.42,-359.48 996.24,-704.5 1560.33,-1031.17 1130.3,-652.28 2414.41,-1237.19 3799.42,-1732.14 1381.12,-499.18 2858.56,-910.52 4372.68,-1242.13 1514.83,-331.26 3066.7,-587.37 4623.86,-770.11 778.93,-92.08 1558.57,-168.28 2337.86,-231.07 778.93,-59.97 1556.81,-108.66 2332.56,-142.52 193.68,-8.12 387,-14.47 580.68,-21.52l290.33 -10.23 289.63 -7.41 578.91 -14.11 576.79 -7.76 288.57 -3.88 287.52 -0.71 575.03 -1.41 572.91 4.59c190.85,1.76 382.06,2.46 571.85,7.05l570.09 10.94 142.52 2.82 143.23 3.53 281.87 7.76c375.71,9.88 751.77,19.75 1128.53,33.51 377.12,12 753.19,25.76 1127.84,40.57 375.7,13.41 749.65,30.69 1123.95,47.27 1496.83,66.68 2983.79,153.11 4460.87,255.77 1477.42,102.66 2944.63,222.25 4403.01,354.19 1457.68,132.64 2907.59,276.57 4352.22,426.5l4330.35 450.5c1446.39,143.94 2895.24,283.64 4360.68,394.41 732.72,55.03 1469.68,103.01 2211.57,139.7 741.89,37.75 1488.72,64.2 2240.84,75.84 1503.89,24.35 3029.3,-5.64 4561.07,-121 765.52,-57.15 1531.4,-132.99 2294.46,-230.01 763.06,-97.37 1522.59,-214.84 2275.77,-350.66 1189.95,-214.02 2360.74,-476.49 3509.08,-772.59l0 5664.55 -67733.32 0 0 -758.7z\" class=\"fil1\" data-v-741b15d0></path> <path d=\"M-0 7646.33c132.56,-111.11 271.17,-220.92 414.87,-329.36 460.03,-347.48 970.14,-682.62 1521.89,-1002.24 1105.96,-637.82 2367.49,-1217.44 3732.39,-1716.26 1361.37,-502.71 2821.51,-926.4 4321.17,-1277.06 1500.01,-350.31 3039.89,-632.18 4587.52,-845.96 774,-107.24 1549.4,-199.67 2324.81,-280.11 775.05,-77.61 1549.75,-144.99 2322.34,-198.26 193.32,-13.05 385.93,-23.99 578.9,-36.33l289.28 -17.64 288.57 -14.82 577.15 -29.63 575.73 -23.29 287.52 -11.64 287.16 -8.82 573.61 -17.28 571.5 -12c190.5,-3.52 381.36,-8.82 570.8,-9.87l569.38 -5.65 142.17 -1.41 142.88 -0.71 281.51 -0.7c375.36,-1.41 750.71,-2.82 1127.48,-0.71 376.77,0.71 752.12,2.83 1126.42,6 375.36,1.76 749.3,7.41 1123.24,12.35 1495.43,19.75 2982.04,58.21 4459.47,112.18 1477.42,53.98 2945.33,123.83 4405.12,205.32 1459.09,82.2 2910.42,174.98 4356.81,273.75l4335.99 297.04c1447.8,93.14 2898.42,182.04 4364.22,243.42 733.07,30.69 1469.67,54.68 2211.56,67.73 741.19,14.11 1487.31,17.64 2238.37,7.41 1501.07,-19.76 3021.9,-90.31 4546.6,-240.59 761.65,-74.44 1523.65,-166.52 2281.77,-277.99 757.77,-112.19 1512.01,-242.71 2258.48,-390.17 1340.45,-263.98 2654.18,-585.32 3936.65,-943.38l0 241.46 0 -0.32c-1264.24,332.37 -2556.89,627.52 -3868.91,873.69 -761.3,142.52 -1528.94,268.11 -2299.05,374.29 -770.12,107.25 -1543.05,196.85 -2314.23,267.41 -1543.05,140.05 -3078.69,210.96 -4590.69,227.19 -756.01,7.76 -1506.72,3.88 -2253.2,-8.12 -746.12,-13.05 -1488.01,-33.51 -2226.02,-61.03 -1476.03,-53.97 -2939.7,-127.7 -4398.44,-207.78 -1460.14,-77.26 -2915.35,-161.58 -4375.5,-236.36 -1459.09,-75.85 -2921,-146.05 -4388.2,-206.03 -733.78,-29.28 -1467.91,-57.85 -2203.81,-83.25 -735.89,-24.7 -1473.54,-46.57 -2211.9,-66.32 -1477.08,-39.16 -2958.75,-68.09 -4446.41,-84.32l-1116.9 -10.23c-372.53,-3.17 -745.06,-5.29 -1117.6,-6l-1121.83 -1.76 -281.17 0 -138.64 0 -139.7 1.06 -559.5 3.88c-186.27,0.35 -373.59,4.58 -560.57,7.41l-561.62 9.87 -563.03 15.17 -281.52 7.41 -282.22 10.59 -564.45 21.16 -565.85 26.81 -283.28 13.76 -283.28 16.58c-189.09,11.29 -377.83,21.52 -566.92,33.52 -756.7,49.38 -1514.47,107.95 -2272.59,178.85 -758.12,73.38 -1516.59,158.75 -2272.59,258.24 -1512.01,200.38 -3017.31,456.84 -4486.63,783.52 -734.84,163.33 -1459.09,345.01 -2169.59,543.63 -711.2,197.91 -1407.93,414.51 -2081.74,650.52 -1349.02,470.96 -2615.49,1015.65 -3739.44,1625.95 -560.92,305.51 -1090.09,625.48 -1569.51,960.97 -199.61,140.05 -393.8,282.32 -576.8,427.22l0 -141.96z\" class=\"fil2\" data-v-741b15d0></path></g></svg></div> <div class=\"container\" data-v-741b15d0><div class=\"row row-cols-lg-2 row-cols-1 align-items-center\" data-v-741b15d0><div class=\"col\" data-v-741b15d0><div class=\"faq-left-image mt-3 mt-xl-0 mb-3 mb-xl-0\" data-v-741b15d0><img src=\"/images/sub100/integracao.svg?20230504\" width=\"530\" height=\"503\" alt=\"Integrações\" data-v-741b15d0> <div class=\"shape tomada scene d-none d-xl-block\" data-v-741b15d0><span data-depth data-v-741b15d0><img src=\"/images/sub100/tomada.svg?20220404\" width=\"455\" height=\"163\" alt=\"Através do software\" class=\"svgInject\" data-v-741b15d0></span></div></div></div> <div class=\"col\" data-v-741b15d0><div class=\"faq-content-area\" data-v-741b15d0><div data-aos=\"fade-up\" class=\"section-title text-center mb-50\" data-v-741b15d0><h4 class=\"title fz-30 max-mb-10 max-mb-md-30\" data-v-741b15d0>Integrações</h4> <p class=\"max-mb-30 fz-sm-18\" data-v-741b15d0>Através do software para loteamentos SGL, Integre-se com as melhores ferramentas do mercado, sejam elas de marketing, comunicação ou contábil.</p></div> <div class=\"shape empresa scene d-none d-xl-block\" data-v-741b15d0><span data-depth data-v-741b15d0><img src=\"/images/sub100/empresa.svg?20220404\" width=\"455\" height=\"142\" alt=\"Empresa\" class=\"svgInject\" data-v-741b15d0></span></div></div></div></div></div> "),_vm._ssrNode("<div class=\"bottom-shape-integration\" data-v-741b15d0>","</div>",[_vm._ssrNode("<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" width=\"677.333mm\" height=\"91.9365mm\" version=\"1.1\" viewBox=\"0 0 67733.32 9193.65\" style=\"shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd\" data-v-741b15d0>","</svg>",[_vm._ssrNode("<g id=\"integracaoVetorBottom\" data-v-741b15d0>","</g>",[_c('metadata',{attrs:{"id":"CorelCorpID_0Corel-Layer"}}),_vm._ssrNode(" <rect x=\"-0\" y=\"0\" width=\"67733.32\" height=\"9193.65\" class=\"fil0\" data-v-741b15d0></rect> <path d=\"M67733.32 0l0 4.23 0 82.55 0 78.4c-52.35,41.33 -105.39,82.48 -159.1,123.44 -473.43,360.18 -996.6,705.55 -1560.69,1032.93 -1130.3,653.7 -2414.41,1239.31 -3799.42,1735.31 -442.98,160.34 -895.89,311.65 -1356.72,454.22 -255.31,94.38 -494.87,168.74 -698.86,207.85 -756.96,216.33 -1532.1,410.07 -2317.1,582.18 -1514.82,331.61 -3066.69,588.43 -4624.21,771.88 -778.58,92.07 -1558.57,168.27 -2337.5,231.42 -778.94,59.97 -1557.17,108.65 -2332.92,142.87 -193.68,8.12 -387,14.12 -580.68,21.52l-290.33 10.23 -289.28 7.41 -579.26 14.47 -576.79 7.76 -288.57 3.53 -287.52 1.05 -575.03 1.06 -572.91 -4.23c-190.85,-2.12 -382.06,-2.47 -571.85,-7.06l-570.09 -10.93 -142.52 -2.83 -143.23 -3.52 -281.87 -7.76c-375.71,-9.88 -751.77,-19.76 -1128.53,-33.52 -377.12,-11.99 -753.18,-25.75 -1127.83,-40.57 -375.71,-13.4 -749.66,-30.69 -1123.95,-47.27 -1496.84,-66.67 -2983.8,-153.11 -4460.88,-255.76 -1477.42,-103.01 -2944.63,-222.61 -4403.01,-354.55 -1458.03,-132.99 -2907.59,-276.93 -4352.22,-427.21l-4330.35 -450.85c-1446.38,-144.28 -2895.6,-283.98 -4360.68,-394.76 -732.72,-55.38 -1469.67,-103.01 -2211.92,-140.05 -741.54,-37.39 -1488.37,-63.85 -2240.84,-75.49 -1503.54,-24.35 -3028.95,5.64 -4560.71,121.35 -765.53,57.15 -1531.77,133 -2294.82,230.37 -763.06,97.71 -1522.59,215.19 -2275.42,351.36 -1334.39,240.57 -2644.43,542.03 -3925.72,883.27l0 12.27 37.05 -8.3c180.27,-39.51 330.55,-136.88 514.7,-171.1 286.39,-53.49 1252.64,-335.19 1304.24,-401.46 -599.34,124.32 -1294.67,273.21 -1855.99,420.27l0 -107.87 0 -0.62 0 -4587.49 67733.32 0z\" class=\"fil1\" data-v-741b15d0></path>")],2)])])],2);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/HeroIntegration.vue?vue&type=template&id=741b15d0&scoped=true

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/HeroIntegration.vue

var script = {}
function injectStyles (context) {
  
  var style0 = __webpack_require__(200)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "741b15d0",
  "56968020"
  
)

/* harmony default export */ var HeroIntegration = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-hero-integration.js.map
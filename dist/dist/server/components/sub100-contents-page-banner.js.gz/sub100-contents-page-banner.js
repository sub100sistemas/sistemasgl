exports.ids = [6];
exports.modules = {

/***/ 229:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/PageBanner.vue?vue&type=template&id=5148a70e
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"page-banner-section section-padding bg-cover",style:_vm.bgImg},[_vm._ssrNode("<div class=\"container\"><div class=\"row\"><div class=\"col-12\"><div class=\"page-banner-title\"><h2 class=\"title\">"+_vm._ssrEscape(_vm._s(_vm.title))+"</h2></div></div></div></div>")]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/PageBanner.vue?vue&type=template&id=5148a70e

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/PageBanner.vue?vue&type=script&lang=js
/* harmony default export */ var PageBannervue_type_script_lang_js = ({props:['bgImg','title']});
// CONCATENATED MODULE: ./components/sub100/contents/PageBanner.vue?vue&type=script&lang=js
 /* harmony default export */ var contents_PageBannervue_type_script_lang_js = (PageBannervue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/PageBanner.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  contents_PageBannervue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "dea689fa"
  
)

/* harmony default export */ var PageBanner = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-page-banner.js.map
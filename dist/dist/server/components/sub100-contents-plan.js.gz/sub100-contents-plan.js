exports.ids = [19];
exports.modules = {

/***/ 147:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(177);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("35b76ca7", content, true, context)
};

/***/ }),

/***/ 176:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Plan_vue_vue_type_style_index_0_id_c9e835d2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(147);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Plan_vue_vue_type_style_index_0_id_c9e835d2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Plan_vue_vue_type_style_index_0_id_c9e835d2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Plan_vue_vue_type_style_index_0_id_c9e835d2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Plan_vue_vue_type_style_index_0_id_c9e835d2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 177:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".dark-mode #curvaBackgroundBottom .fil0{fill:#161821!important}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 232:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/Plan.vue?vue&type=template&id=c9e835d2
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"plan-section pb-5 pt-5"},[_vm._ssrNode("<div class=\"container\"><div class=\"row align-items-center\"><div class=\"col order-2\"><div class=\"about-content max-w-100 text-center\"><h1 class=\"sub-title mb-0\">Planos - <strong>Sistema de Gestão de loteamentos SGL</strong></h1> <h3 class=\"title fz-30 p-4\">\n                        Elaboramos planos que se encaixam ao perfil de seus\n                        <div class=\"d-inline d-xl-block\"> empreendimentos e suprem as necessidades de sua Loteadora</div></h3></div></div></div> <div class=\"row max-mb-n30\"><div class=\"col box-plan text-center\"><p class=\"sub-title fz-22 mb-0 titlePlano\"> Plano</p> <h3 class=\"mb-0\">Paraná</h3> <p class=\"mt-4 mb-4 fz-16\"><strong>Início da expansão imobiliária,<br>1 empreendimento</strong></p> <hr> <p class=\"mb-0 fz-16\"><strong>Setup inicial</strong></p> <p class=\"mais mb-0\"> +</p> <h4>Mensalidade</h4> <a href=\"/sobre-o-setup/\" class=\"btn btn-outline-primary mb-3 d-block mt-4\">Sobre o setup</a> <a href=\"/fale-conosco/\" class=\"btn btn-secondary btn-hover-secondary-two mb-0 d-block\">Fale conosco</a></div> <div class=\"col box-plan text-center\"><p class=\"sub-title fz-22 mb-0 titlePlano\"> Plano</p> <h3 class=\"mb-0\">Minas Gerais</h3> <p class=\"mt-4 mb-4 fz-16\"><strong>Em plena expansão imobiliária,<br> com até 4 empreendimentos</strong></p> <hr> <p class=\"mb-0 fz-16\"><strong>Setup inicial</strong></p> <p class=\"mais mb-0\"> +</p> <h4>Mensalidade</h4> <a href=\"/sobre-o-setup/\" class=\"btn btn-outline-primary mb-3 d-block mt-4\">Sobre o setup</a> <a href=\"/fale-conosco/\" class=\"btn btn-secondary btn-hover-secondary-two mb-0 d-block\">Fale conosco</a></div> <div class=\"col box-plan text-center\"><p class=\"sub-title fz-22 mb-0 titlePlano\"> Plano</p> <h3 class=\"mb-0\">Mato Grosso</h3> <p class=\"mt-4 mb-4 fz-16\"><strong>Quer e precisa mais? O SGL se<br>adapta às suas necessidades</strong></p> <hr> <h4 class=\"espaco\">Quero personalizar<div class=\"d-block d-xl-initial\">meu plano</div></h4> <a href=\"/fale-conosco/\" class=\"btn btn-secondary btn-hover-secondary-two mb-0 d-block\">Fale conosco</a></div></div></div> <div class=\"sub100-demo d-none d-md-block\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" width=\"2500px\" height=\"282px\" version=\"1.1\" viewBox=\"0 0 25000 2814.1\" style=\"shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd\"><g id=\"curvaBackgroundBottom\"><rect y=\"189.1\" width=\"25000\" height=\"2625\" class=\"fil0\"></rect> <path d=\"M0 0l25000 0 0 785.3c-1706,-198.3 -5122.9,-299.9 -10454.2,822.1 -3662.1,770.7 -7974.2,250.5 -7974.2,250.5 0,0 -2877.2,-134 -4960.7,-541.9 -601.7,-117.8 -1135.4,-209.2 -1610.9,-278.8l0 -1037.2z\" class=\"fil1\"></path> <path d=\"M25000 623c-1706,-190.6 -5122.9,-280.8 -10454.2,841.2 -3012.5,634 -6464.3,500.2 -7594.3,432.7 1130,105 4581.8,344.5 7594.3,-289.5 5331.3,-1122 8748.2,-1020.4 10454.2,-822.1l0 -162.3z\" class=\"fil2\"></path></g></svg></div>")]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/Plan.vue?vue&type=template&id=c9e835d2

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/Plan.vue?vue&type=script&lang=js
/* harmony default export */ var Planvue_type_script_lang_js = ({components:{ContactForm:()=>__webpack_require__.e(/* import() */ 7).then(__webpack_require__.bind(null, 274))}});
// CONCATENATED MODULE: ./components/sub100/contents/Plan.vue?vue&type=script&lang=js
 /* harmony default export */ var contents_Planvue_type_script_lang_js = (Planvue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/Plan.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(176)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  contents_Planvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  injectStyles,
  null,
  "2b68b6de"
  
)

/* harmony default export */ var Plan = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-plan.js.map
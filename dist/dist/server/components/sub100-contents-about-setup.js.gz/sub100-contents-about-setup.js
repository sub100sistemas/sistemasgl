exports.ids = [11];
exports.modules = {

/***/ 149:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(181);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("b2dd8d1a", content, true, context)
};

/***/ }),

/***/ 180:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutSetup_vue_vue_type_style_index_0_id_537d397a_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(149);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutSetup_vue_vue_type_style_index_0_id_537d397a_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutSetup_vue_vue_type_style_index_0_id_537d397a_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutSetup_vue_vue_type_style_index_0_id_537d397a_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutSetup_vue_vue_type_style_index_0_id_537d397a_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 181:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".fz-18{font-size:18px}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 281:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/AboutSetup.vue?vue&type=template&id=537d397a
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"about-section section-padding bg-F5F5F5"},[_vm._ssrNode("<div class=\"container\">","</div>",[_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two text-center\"><h1 class=\"title fz-28\">Sobre o setup</h1> <p class=\"fz-20 mt-3 mb-5\">Entenda o que poderá compor o <a name=\"Sobre o setup\" style=\"cursor:text;text-decoration:none\">setup</a> de implantação do Sistema de Gestão Loteamento SGL</p></div> "),_vm._ssrNode("<div class=\"row row-cols-xl-3 row-cols-md-2 row-cols-1 max-mb-n60 pt-3\">","</div>",[_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two col max-mb-60\">","</div>",[_vm._ssrNode("<div class=\"icon-box-list\">","</div>",[_vm._ssrNode("<div class=\"icon\">","</div>",[_c('inline-svg',{attrs:{"src":"/images/icons/simulador.svg?20220404","alt":"icon"}})],1),_vm._ssrNode(" <div class=\"content\"><h3 class=\"title color-secondary\">Treinamentos nos<br>módulos de vendas</h3> <div class=\"desc\"><p><i class=\"fa fas fa-check\"></i> Controle de atendimento<br> <i class=\"fa fas fa-check\"></i> Mapa interativo<br> <i class=\"fa fas fa-check\"></i> Comercial<br> <i class=\"fa fas fa-check\"></i> Incorporação\n                            </p></div></div>")],2)]),_vm._ssrNode(" "),_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two col max-mb-60\">","</div>",[_vm._ssrNode("<div class=\"icon-box-list\">","</div>",[_vm._ssrNode("<div class=\"icon\">","</div>",[_c('inline-svg',{attrs:{"src":"/images/icons/administrativo.svg?20220404","alt":"icon"}})],1),_vm._ssrNode(" <div class=\"content\"><h3 class=\"title color-secondary\">Treinamentos nos<br>módulos de administrativo</h3> <div class=\"desc\"><p><i class=\"fa fas fa-check\"></i> Administrativo<br> <i class=\"fa fas fa-check\"></i> Financeiro<br> <i class=\"fa fas fa-check\"></i> Gestão de inadimplência<br> <i class=\"fa fas fa-check\"></i> Fiscal<br> <i class=\"fa fas fa-check\"></i> Portal do cliente\n                            </p></div></div>")],2)]),_vm._ssrNode(" "),_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two col max-mb-60\">","</div>",[_vm._ssrNode("<div class=\"icon-box-list\">","</div>",[_vm._ssrNode("<div class=\"icon\">","</div>",[_c('inline-svg',{attrs:{"src":"/images/icons/financeiro.svg?20220404","alt":"icon"}})],1),_vm._ssrNode(" <div class=\"content\"><h3 class=\"title color-secondary\">Homologações</h3> <div class=\"desc\"><p><i class=\"fa fas fa-check\"></i> Boletos<br> <i class=\"fa fas fa-check\"></i> Conciliações bancárias<br> <i class=\"fa fas fa-check\"></i> Contrato\n                            </p></div></div>")],2)]),_vm._ssrNode(" "),_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two col max-mb-60\">","</div>",[_vm._ssrNode("<div class=\"icon-box-list\">","</div>",[_vm._ssrNode("<div class=\"icon\">","</div>",[_c('inline-svg',{attrs:{"src":"/images/icons/integracao.svg?20220404","alt":"icon"}})],1),_vm._ssrNode(" <div class=\"content\"><h3 class=\"title color-secondary\">Integrações</h3> <div class=\"desc\"><p><i class=\"fa fas fa-check\"></i> Importações de Leads<br> <i class=\"fa fas fa-check\"></i> Mensageria <span class=\"d-block pl-3\">(WhatsAPP API* e WhatsAPP Web, SMS* e SPC)</span> <span class=\"d-block pl-3\" style=\"font-size:12px\">* Não incluso no setup</span></p></div></div>")],2)]),_vm._ssrNode(" "),_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two col max-mb-60\">","</div>",[_vm._ssrNode("<div class=\"icon-box-list\">","</div>",[_vm._ssrNode("<div class=\"icon\">","</div>",[_c('inline-svg',{attrs:{"src":"/images/icons/fiscal.svg?20220404","alt":"icon"}})],1),_vm._ssrNode(" <div class=\"content\"><h3 class=\"title color-secondary\">Exportações</h3> <div class=\"desc\"><p><i class=\"fa fas fa-check\"></i> Contábil<br> <i class=\"fa fas fa-check\"></i> SPED<br> <i class=\"fa fas fa-check\"></i> Dimob\n                           </p></div></div>")],2)]),_vm._ssrNode(" "),_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two col max-mb-60\">","</div>",[_vm._ssrNode("<div class=\"icon-box-list\">","</div>",[_vm._ssrNode("<div class=\"icon\">","</div>",[_c('inline-svg',{attrs:{"src":"/images/icons/importacao.svg?20220404","alt":"icon"}})],1),_vm._ssrNode(" <div class=\"content\"><h3 class=\"title color-secondary\">Importação</h3> <div class=\"desc\"><p><i class=\"fa fas fa-check\"></i> Base de dados do sistema <span class=\"d-block pl-3\"> atual da loteadora para o SGL</span><span style=\"font-size:12px;padding-left:18px;\">*Não incluso no setup</span></p></div></div>")],2)])],2)],2)]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/AboutSetup.vue?vue&type=template&id=537d397a

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/AboutSetup.vue

var script = {}
function injectStyles (context) {
  
  var style0 = __webpack_require__(180)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  injectStyles,
  null,
  "1b4f78d8"
  
)

/* harmony default export */ var AboutSetup = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-about-setup.js.map
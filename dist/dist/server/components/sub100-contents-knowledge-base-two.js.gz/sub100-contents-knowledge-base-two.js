exports.ids = [18];
exports.modules = {

/***/ 150:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(183);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("5bd65437", content, true, context)
};

/***/ }),

/***/ 182:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_knowledgeBaseTwo_vue_vue_type_style_index_0_id_720d0cc2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(150);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_knowledgeBaseTwo_vue_vue_type_style_index_0_id_720d0cc2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_knowledgeBaseTwo_vue_vue_type_style_index_0_id_720d0cc2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_knowledgeBaseTwo_vue_vue_type_style_index_0_id_720d0cc2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_knowledgeBaseTwo_vue_vue_type_style_index_0_id_720d0cc2_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 183:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".fz-18{font-size:18px}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 236:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/knowledgeBaseTwo.vue?vue&type=template&id=720d0cc2
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"about-section section-padding"},[_vm._ssrNode("<div class=\"container\">","</div>",[_vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two text-center\"><h2 class=\"title fz-28\">Vantagens que a &quot;Base de Conhecimento&quot; oferece</h2> <p class=\"fz-20 mt-3 mb-5\">Uma “Base de Conhecimento” sólida e bem estruturada traz inúmeros benefícios <span class=\"w-0 w-xl-100 d-initial d-xl-block\">ao seu negócio. Abaixo elencamos os principais</span></p></div> "),_vm._ssrNode("<div class=\"row row-cols-xl-3 row-cols-md-2 row-cols-1 max-mb-n60\">","</div>",_vm._l(_vm.features,function(feature){return _vm._ssrNode("<div data-aos=\"fade-up\" class=\"section-title-two col max-mb-60\">","</div>",[_vm._ssrNode("<div class=\"icon-box text-center\">","</div>",[_vm._ssrNode("<div class=\"icon\">","</div>",[_c('inline-svg',{attrs:{"src":feature.icon,"alt":"icon"}})],1),_vm._ssrNode(" <div class=\"content Base\"><h3 class=\"title Base color-secondary\">"+_vm._ssrEscape(_vm._s(feature.title))+"</h3> <div class=\"desc\"><p>"+_vm._ssrEscape(_vm._s(feature.desc))+"</p></div></div>")],2)]);}),0)],2)]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/knowledgeBaseTwo.vue?vue&type=template&id=720d0cc2

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/knowledgeBaseTwo.vue?vue&type=script&lang=js
/* harmony default export */ var knowledgeBaseTwovue_type_script_lang_js = ({data(){return{features:[{icon:"/images/icons/atendimento.svg?20220404",title:"Agilidade no atendimento",desc:"O próprio cliente tem a possibilidade de solucionar sozinho as dúvidas em relação ao produto ou serviço prestado por sua empresa. É comum disponibilizar a “Base de Conhecimento” em formato FAQ (perguntas frequentes), para o cliente externo."},{icon:"/images/icons/maos.svg?20220404",title:"Maior engajamento das equipes",desc:"Para elaboração de uma “base de Conhecimento” sólida e eficiente, necessário se faz o engajamento das equipes dos diversos setores da empresa, desta forma aumentando e fortalecendo a sinergia dos colaboradores."},{icon:"/images/icons/instrutor.svg?20220404",title:"Melhoria no treinamento de novos colaboradores",desc:"O treinamento interno (colaboradores e novos colaboradores) é potencializado através do “PAP” já existente na “Base de Conhecimento”, pois o colaborador tem acesso rápido, fácil e no momento que se fizer necessário,  às soluções e vantagens que o sistema oferece. "},{icon:"/images/icons/financeiro.svg?20220404",title:"Redução de custos com pessoal",desc:"Em virtude da baixa complexibilidade e de que geralmente as dúvidas dos clientes são as mesmas, a contratação de profissionais para atender as demandas do “atendimento ao cliente” se tornam desnecessárias."},{icon:"/images/icons/usuario.svg?20220404",title:"Aumenta a satisfação dos clientes",desc:'O grau de satisfação de seus clientes cresce, ao verem que suas duvidas foram sanadas de maneira simples e eficiente, através das informações e soluções existentes na “Base de conhecimento".'},{icon:"/images/icons/administrativo.svg?20220404",title:"Diminuição de retrabalhos",desc:"Com a melhora na capacitação dos colaboradores, será visível a diminuição das falhas e retrabalhos , impactando positivamente na redução de custos."}]};}});
// CONCATENATED MODULE: ./components/sub100/contents/knowledgeBaseTwo.vue?vue&type=script&lang=js
 /* harmony default export */ var contents_knowledgeBaseTwovue_type_script_lang_js = (knowledgeBaseTwovue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/knowledgeBaseTwo.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(182)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  contents_knowledgeBaseTwovue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  injectStyles,
  null,
  "805202b6"
  
)

/* harmony default export */ var knowledgeBaseTwo = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-knowledge-base-two.js.map
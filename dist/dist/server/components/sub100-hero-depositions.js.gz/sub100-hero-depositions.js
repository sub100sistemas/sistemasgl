exports.ids = [25];
exports.modules = {

/***/ 161:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(205);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("62719c0a", content, true, context)
};

/***/ }),

/***/ 204:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroDepositions_vue_vue_type_style_index_0_id_9c109c92_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(161);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroDepositions_vue_vue_type_style_index_0_id_9c109c92_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroDepositions_vue_vue_type_style_index_0_id_9c109c92_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroDepositions_vue_vue_type_style_index_0_id_9c109c92_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_HeroDepositions_vue_vue_type_style_index_0_id_9c109c92_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 205:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".bg-e9eefd[data-v-9c109c92]{background:#e9eefd}.dark-mode .author-info img[data-v-9c109c92]{filter:brightness(0) invert(1)}.dark-mode .bg-e9eefd[data-v-9c109c92]{background:#111}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 259:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroDepositions.vue?vue&type=template&id=9c109c92&scoped=true
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"testimonial-section section-padding bg-e9eefd"},[_vm._ssrNode("<div class=\"container-fluid pl-80 pl-lg-15 pl-md-15 pl-sm-15 pl-xs-15 pr-80 pr-lg-15 pr-md-15 pr-sm-15 pr-xs-15\" data-v-9c109c92>","</div>",[_c('SectionHeader',{attrs:{"subTitle":"Depoimentos","title":"O que <span> nossos clientes </span> dizem sobre nossos produtos e serviços","alignment":"text-center section-title"}}),_vm._ssrNode(" "),_vm._ssrNode("<div data-aos=\"fade-up\" class=\"testimonial-slider-two\" data-v-9c109c92>","</div>",[_c('swiper',{attrs:{"options":_vm.swiperOption}},_vm._l(_vm.testimonials,function(testimonial){return _c('div',{key:testimonial.index,staticClass:"swiper-slide"},[_c('div',{staticClass:"testimonial-two testimonial-three max-mb-30 text-center"},[_c('div',{staticClass:"author-info mb-30"},[_c('div',{staticClass:"mr-3"},[_c('img',{attrs:{"src":testimonial.imgSrc,"width":testimonial.width,"height":testimonial.height,"alt":testimonial.name}})]),_vm._v(" "),_c('div',{staticClass:"cite"},[_c('p',{staticClass:"position"},[_vm._v(_vm._s(testimonial.city))])])]),_vm._v(" "),_c('div',{staticClass:"content"},[_c('h4',{staticClass:"title"},[_vm._v(_vm._s(testimonial.title))]),_vm._v(" "),_c('p',[_vm._v(_vm._s(testimonial.desc))])]),_vm._v(" "),_c('div',{staticClass:"author-info"},[_c('div',{staticClass:"cite"},[_c('h5',{staticClass:"name"},[_vm._v(_vm._s(testimonial.name))]),_vm._v(" "),_c('span',{staticClass:"position"},[_vm._v(_vm._s(testimonial.position))])])])])]);}),0),_vm._ssrNode(" <div class=\"swiper-pagination text-center\" data-v-9c109c92></div>")],2)],2)]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/HeroDepositions.vue?vue&type=template&id=9c109c92&scoped=true

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/HeroDepositions.vue?vue&type=script&lang=js
/* harmony default export */ var HeroDepositionsvue_type_script_lang_js = ({data(){return{swiperOption:{spaceBetween:50,loop:true,speed:1000,centeredSlides:true,autoHeight:true,autoplay:{delay:10000,disableOnInteraction:false,pauseOnMouseEnter:true},pagination:{el:'.testimonial-slider-two .swiper-pagination',type:"bullets",clickable:true},// Responsive breakpoints
breakpoints:{1200:{slidesPerView:3},992:{slidesPerView:2},300:{slidesPerView:1}}},testimonials:[{title:"",desc:"A parceria entre Campo Incorporadora e a SUB100 Sistemas acontece de maneira proativa e madura, pois temos um canal de interação direto que sempre nos direciona às melhorias e evoluções no sistema SGL.",name:"Lucian Alves Moreira",position:"Contador",city:"Primavera do Leste, MT",imgSrc:"/images/depositions/campo.png",width:"117",height:"55"},{title:"",desc:"O fácil acesso aos diretores da SUB100 Sistemas, nos dá confiança e a certeza de sempre termos nossas necessidades e objetivos em relação ao SGL atendidas.",name:"Indira Mendes Maia",position:"Coordenadora de vendas",city:"Montes Claros, MG",imgSrc:"/images/depositions/viaubanismo.png",width:"149",height:"85"},{title:"",desc:"Lançamos o maior condomínio de lazer do sul do Brasil, e convidamos a SUB100 Sistemas a desenvolver um programa inovador que nos auxiliasse na comercialização do empreendimento, assim surgiu o SGL.",name:"André Ricardo dos Reis Buzzo",position:"Diretor",city:"Maringá, PR",imgSrc:"/images/depositions/greenfish.png",width:"173",height:"55"}]};}});
// CONCATENATED MODULE: ./components/sub100/HeroDepositions.vue?vue&type=script&lang=js
 /* harmony default export */ var sub100_HeroDepositionsvue_type_script_lang_js = (HeroDepositionsvue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/HeroDepositions.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(204)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  sub100_HeroDepositionsvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "9c109c92",
  "61e768d5"
  
)

/* harmony default export */ var HeroDepositions = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-hero-depositions.js.map
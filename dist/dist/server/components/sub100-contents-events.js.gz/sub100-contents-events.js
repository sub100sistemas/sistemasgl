exports.ids = [14];
exports.modules = {

/***/ 238:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/Events.vue?vue&type=template&id=3fb713da
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"about-section pt-5 pb-3",class:_vm.addClassName},[_vm._ssrNode("<div class=\"container\"><div class=\"row align-items-center\"><div class=\"col order-2\"><div class=\"about-content max-w-100 text-center\"><h1 class=\"title\">Eventos online</h1> <p class=\"fz-18\">\n                        Com palestras que trazem grandes novidades e inovações tecnológicas sobre o setor, além de apresentar as melhorias realizadas nos produtos da SUB100 Sistemas.\n                    </p></div></div></div></div>")]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/sub100/contents/Events.vue?vue&type=template&id=3fb713da

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/sub100/contents/Events.vue?vue&type=script&lang=js
/* harmony default export */ var Eventsvue_type_script_lang_js = ({props:['addClassName'],components:{ShapeWithAnimation:()=>__webpack_require__.e(/* import() */ 5).then(__webpack_require__.bind(null, 141))}});
// CONCATENATED MODULE: ./components/sub100/contents/Events.vue?vue&type=script&lang=js
 /* harmony default export */ var contents_Eventsvue_type_script_lang_js = (Eventsvue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/sub100/contents/Events.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  contents_Eventsvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "2fb222fe"
  
)

/* harmony default export */ var Events = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=sub100-contents-events.js.map